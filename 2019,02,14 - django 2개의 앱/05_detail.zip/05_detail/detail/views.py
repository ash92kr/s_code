from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'detail/index.html')
    
def qna(request):
    return render(request, 'detail/qna.html')
    
def mypage(request):
    return render(request, 'detail/mypage.html')

def signup(request):
    return render(request, 'detail/signup.html')
    
def routing(request, name):
    return render(request, 'detail/404.html', {'name': name})